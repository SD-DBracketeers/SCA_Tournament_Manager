import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-bracket",
  templateUrl: "./bracket.component.html",
  styleUrls: ["./bracket.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BracketComponent {}
