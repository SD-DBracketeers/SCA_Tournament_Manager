import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-search-participants",
  templateUrl: "./search-participants.component.html",
  styleUrls: ["./search-participants.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SearchParticipantsComponent {}
