import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-admin-add-new-participant",
  templateUrl: "./admin-add-new-participant.component.html",
  styleUrls: ["./admin-add-new-participant.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminAddNewParticipantComponent {}
