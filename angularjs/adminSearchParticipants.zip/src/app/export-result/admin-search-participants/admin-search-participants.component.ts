import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-admin-search-participants",
  templateUrl: "./admin-search-participants.component.html",
  styleUrls: ["./admin-search-participants.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminSearchParticipantsComponent {}
