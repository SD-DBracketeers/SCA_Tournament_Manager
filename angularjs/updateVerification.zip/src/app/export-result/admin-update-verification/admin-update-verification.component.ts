import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-admin-update-verification",
  templateUrl: "./admin-update-verification.component.html",
  styleUrls: ["./admin-update-verification.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminUpdateVerificationComponent {}
