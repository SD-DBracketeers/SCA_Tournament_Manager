import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-admin-update-participant",
  templateUrl: "./admin-update-participant.component.html",
  styleUrls: ["./admin-update-participant.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminUpdateParticipantComponent {}
