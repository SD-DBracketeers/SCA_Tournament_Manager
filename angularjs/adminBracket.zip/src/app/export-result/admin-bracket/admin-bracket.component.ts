import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-admin-bracket",
  templateUrl: "./admin-bracket.component.html",
  styleUrls: ["./admin-bracket.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminBracketComponent {}
