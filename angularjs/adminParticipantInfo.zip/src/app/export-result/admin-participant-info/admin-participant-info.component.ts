import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-admin-participant-info",
  templateUrl: "./admin-participant-info.component.html",
  styleUrls: ["./admin-participant-info.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminParticipantInfoComponent {}
