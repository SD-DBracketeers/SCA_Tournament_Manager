import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-create-tournament",
  templateUrl: "./create-tournament.component.html",
  styleUrls: ["./create-tournament.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateTournamentComponent {}
