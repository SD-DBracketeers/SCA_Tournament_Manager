import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-participant-info",
  templateUrl: "./participant-info.component.html",
  styleUrls: ["./participant-info.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ParticipantInfoComponent {}
